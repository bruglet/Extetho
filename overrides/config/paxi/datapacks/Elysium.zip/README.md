# Elysium

Elysium is a datapack for Minecraft Java Edition developed for use in the Extetho Modpack (and formerly for Atlas).

Elysium's role is to better integrate Extetho's mods together, and apply balancing changes for use on multiplayer servers.

Elysium contains code and assets from other mods (all from the Extetho Modpack). Because of this, Elysium is not avaliable as a standalone download and is only avaliable when bundled within Extetho. Credits to all original authors can be found within credits.txt (Coming Soon), also within this repository/zip file.


## Elysium Changes

Elysium mostly only changes the position of Advancements to make it easier to manage since version 2.0.0. 


## Dependancies

Elysium requires the Extetho Modpack to be installed. (It should be already as this datapack is only included as a part of Extetho.)

If for some reason Extetho is not installed or this pack is extracted from Extetho **for personal use only**, please delete this datapack immediately.


## Copyright and Distribution

Because of Elysium's nature, this datapack is only allowed to be distributed as a part of the Atlas or Extetho Modpack. Uploading any part of this pack elsewhere is strictly forbidden as it not only steals my work, but all the work of the authors who's code is featured in this pack.

If this pack is extracted from the Extetho or Atlas Modpack for whatever reason, **it must be used for only private and personal use**, and **must not be redistribiuted**. Please keep the credits and README file intact and attached if you are doing this. (Even though it is really not recommended.)